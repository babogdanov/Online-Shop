#include "Shop.h"

void Shop::printAccount() const {

}