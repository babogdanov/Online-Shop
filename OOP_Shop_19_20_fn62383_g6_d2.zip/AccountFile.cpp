#include "AccountFile.h"
#include <iostream>
#include <cstring>
using namespace std;

AccountFile::AccountFile()
{
	this->accounts = nullptr;
	this->accountsCount = 0;
	this->currentAccount.setUsername("Guest");
	this->currentAccount.setPassword("");
}

void AccountFile::addAccount(Account account)
{
	while (true)
	{
		for (int i = 0; i < this->accountsCount; i++) {
			if (strcmp(this->accounts[i].getUsername(), account.getUsername()) == 0)
			{
				cout << "Username is already taken. Choose another username." << endl;
				return;
			}
		}
		break;
	}
	Account* temp = new Account[this->accountsCount];
		for (int i = 0; i < this->accountsCount; i++) {
			temp[i] = this->accounts[i];
		}
		delete[] accounts;
		this->accountsCount++;
		accounts = new Account[this->accountsCount];
		for (int i = 0; i < this->accountsCount - 1; i++) {
			this->accounts[i] = temp[i];
		}
		this->accounts[this->accountsCount - 1] = account;
		delete[] temp;

		//cout << "You registered successfully. You can now login." << endl;
}

void AccountFile::logIn(Account account)
{
	for (int i = 0; i < this->accountsCount; i++) {
		if (strcmp(this->accounts[i].getUsername(), account.getUsername()) == 0
			&& strcmp(this->accounts[i].getPassword(), account.getPassword()) == 0)
		{
			this->currentAccount = account;
			cout << "You have logged in successfully." << endl;
			return;
		}
	}
	cout << "There is no account with this username and password. Try again or create a new account." << endl;
}

void AccountFile::logOut()
{
	this->currentAccount.setUsername("Guest");
	this->currentAccount.setPassword("");
}
void AccountFile::printAccount() const {
	
	cout <<"You are currently logged in as: "<< this->currentAccount.getUsername() << endl;
	
}