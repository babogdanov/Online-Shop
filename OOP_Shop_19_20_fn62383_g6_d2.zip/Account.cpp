#include "Account.h"
#include <cstring>
void Account::setPassword(const char* password)
{
	this->password = new char[strlen(password) + 1];
	strcpy(this->password, password);
}
char* Account::getPassword() const
{
	return this->password;
}

void Account::setUsername(const char* username)
{
	this->username = new char[strlen(username) + 1];
	strcpy(this->username, username);
}
char* Account::getUsername() const
{
	return this->username;
}


Account::Account()
{
	this->username = new char[6];
	strcpy(this->username, "Guest");
	this->password = nullptr;
}

Account::Account(const char* username,const char* password)
{
	this->username = new char[strlen(username) + 1];
	strcpy(this->username, username);
	this->password = new char[strlen(password) + 1];
	strcpy(this->password, password);
}
