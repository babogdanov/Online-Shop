#include "Product.h"
#include <cstring>
#include <iostream>
using namespace std;
Product::Product()
{
	this->name = nullptr;
	this->price = 0;
	this->category = nullptr;
	this->rating = 0;
}
Product::Product(const char* name, double price,const char* category, double rating)
{
	this->name = new char[strlen(name) + 1];
	strcpy(this->name, name);
	this->price = price;
	this->category = new char[strlen(category) + 1];
	strcpy(this->category, category);
	this->rating = rating;
}
Product::Product(const Product& other)
{
	this->name = new char[strlen(other.name) + 1];
	strcpy(this->name, other.name);
	this->price = other.price;
	this->category = new char[strlen(other.category) + 1];
	strcpy(this->category, other.category);
	this->rating = other.rating;

}
void Product::print() const
{
	cout << "Name: " << this->name << endl;
	cout << "Category: " << this->category << endl;
	cout << "Price: " << this->price << endl;
	cout << "Rating: " << this->rating << endl << endl;
}

const char* Product::getName() const
{
	return this->name;
}
double Product::getPrice() const
{
	return this->price;
}
const char* Product::getCategory() const
{
	return this->category;
}
double Product::getRating() const
{
	return this->rating;
}