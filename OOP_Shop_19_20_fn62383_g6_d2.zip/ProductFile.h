#pragma once
#include "Product.h"
class ProductFile: public Product
{
private:
	int productsCount;
	Product* products;
	Product currentProduct;
public:
	void printByCategory(const char* category) const;
	void printAlphabetically() const;
	void printByPrice(const char* order) const;
	void addProduct(Product product);
	
};

