#pragma once
#include "Product.h"
class Shopping_Cart
{
private:
	Product* products;
	int productsCount;

public:

};

