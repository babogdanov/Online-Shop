#include "AccountFile.h"
#include "ProductFile.h"
#include <iostream>

//Max size for both username and password.
const int MAX_SIZE = 20;
using namespace std;
int main()
{
	AccountFile accounts;
	ProductFile products;

	accounts.printAccount();

	Account first("qnko", "1234");
	Account second("joro", "4321");
	accounts.addAccount(first);
	accounts.addAccount(second);



	int toDo;
	cout << "Press 1 to continue as guest, 2 to log in or 3 to create a new account: ";
	cin >> toDo;
	Account current;
	if (toDo == 2 || toDo == 3)
	{
		char username[MAX_SIZE + 1];
		cout << "Choose a username of up to "<< MAX_SIZE << " characters: ";
		cin >> username;
		char password[MAX_SIZE + 1];
		cout << "Choose a password of up to " << MAX_SIZE << " characters: ";
		cin >> password;
		
		current.setUsername(username);
		current.setPassword(password);
		
		if (toDo == 3)
		{
			accounts.addAccount(current);
		}
		
		
		
		else
		{
			accounts.logIn(current);
		}
		
		accounts.printAccount();
	}
	
	

	Product a("nokia", 15, "smartphones", 4.5);
	Product b("motorola", 33, "smartphones", 4);
	Product c("nike", 150, "shoes", 3);
	Product d("adidas", 100, "shoes", 4);
	Product e("reebok", 111, "shoes", 5);
	Product f("sony", 1300, "notebooks", 5);

	products.addProduct(a);
	products.addProduct(b);
	products.addProduct(c);
	products.addProduct(d);
	products.addProduct(e);
	products.addProduct(f);
	
	products.printByCategory("");
	cout << endl << endl;
	products.printAlphabetically();
	cout << endl << endl;
	products.printByPrice("from lower");
	cout << endl << endl;
	products.printByCategory("smartphones");
	return 0;
}