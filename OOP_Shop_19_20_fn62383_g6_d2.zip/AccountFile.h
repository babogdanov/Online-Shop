#pragma once
#include "Account.h"

class AccountFile
{
private:
    int accountsCount;
    Account* accounts;
    Account currentAccount;
public:
    AccountFile();
    void addAccount(Account account);
    void logIn(Account account);
    void logOut();
    void printAccount() const;
    
};


