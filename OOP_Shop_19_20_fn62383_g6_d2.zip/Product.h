#pragma once

class Product
{
private:
	char* name;
	double price;
	char* category;
	double rating;
	
public:
	Product();
	Product(const char*, double, const char*, double);
	Product(const Product&);
    const char* getName() const;
	double getPrice() const;
	const char* getCategory() const;
	double getRating() const;
	void print() const;
	
};

