#pragma once

#include "AccountFile.h"
#include "ProductFile.h"
#include "Cart.h"
class Shop
{
private:
	
public:
	void printAccount() const;

};

