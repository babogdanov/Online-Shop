#pragma once
class Account
{
private:
	char* password;
	char* username;

public:
	void setPassword(const char* p);
	char* getPassword() const;
	void setUsername(const char* u);
	char* getUsername() const;
	
	Account();
	Account(const char*,const char*);
	


};

