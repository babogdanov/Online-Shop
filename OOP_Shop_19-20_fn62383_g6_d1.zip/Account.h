#pragma once
class Account
{
public:

	void setPassword(char* p);
	char* getPassword();
	void setUsername(char* u);
	char* getUsername();
	void Register();
	void LogIn();
	Account();
	Account(char*, char*);

private:
	char* password;
	char* username;

};

