#pragma once
class Product
{
public:
	Product();
	Product(char*, double, char*, double);
	void printByCategory(char* category, Product* products) const;
	void addToCart(Product product);
private:
	char* name;
	double price;
	char* category;
	double rating;
};

