#include "Product.h"
#include <cstring>
Product::Product()
{
	this->name = nullptr;
	this->price = 0;
	this->category = nullptr;
	this->rating = 0;
}
Product::Product(char* name, double price, char* category, double rating)
{
	this->name = new char[strlen(name) + 1];
	strcpy(this->name, name);
	this->price = price;
	this->category = new char[strlen(category) + 1];
	strcpy(this->category, category);
	this->rating = rating;
}

void printByCategory(char* category, Product* products) 
{

}