#pragma once
#include "Account.h"
class File
{
public:
    int accountsCount;
    Account* accounts;
    void addAccount(Account account);
    void LogIn(Account account);
};

