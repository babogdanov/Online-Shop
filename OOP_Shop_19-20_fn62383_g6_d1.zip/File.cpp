#include "File.h"



void File::addAccount(Account account)
{
	Account* temp = new Account[this->accountsCount];
		for (int i = 0; i < this->accountsCount; i++) {
			temp[i] = this->accounts[i];
		}
		delete[] accounts;
		this->accountsCount++;
		accounts = new Account[this->accountsCount];
		for (int i = 0; i < this->accountsCount - 1; i++) {
			this->accounts[i] = temp[i];
		}
		this->accounts[this->accountsCount - 1] = account;
		delete[] temp;
}
void File::LogIn(Account account)
{
	for (int i = 0; i < this->accountsCount; i++) {
		if(this->accounts[i] == account)
	}
}