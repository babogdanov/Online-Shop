#include "Account.h"
#include <cstring>
void Account::setPassword(char* p)
{
	this->password = p;
}
char* Account::getPassword()
{
	return this->password;
}

void Account::setUsername(char* u)
{
	this->username = u;
}
char* Account::getUsername()
{
	return this->username;
}
void Account::Register()
{

}

Account::Account()
{
	this->username = new char[6];
	strcpy(this->username, "Guest");
	this->password = nullptr;
}

Account::Account(char* username, char* password)
{
	this->username = new char[strlen(username) + 1];
	strcpy(this->username, username);
	this->password = new char[strlen(password) + 1];
	strcpy(this->password, password);
}